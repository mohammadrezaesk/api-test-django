from django.urls import path
from .views import TestViewSet
urlpatterns = [
    path("small/",TestViewSet.small),
    path("medium/",TestViewSet.medium),
    path("big/",TestViewSet.big),

]

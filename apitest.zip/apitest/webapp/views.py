from django.shortcuts import render
from rest_framework import viewsets
from django.http import FileResponse

class TestViewSet(viewsets.ModelViewSet):

    def small(self):
        response = FileResponse(open('webapp/small.json', 'rb'))
        return response
    def medium(self):
        response = FileResponse(open('webapp/medium.json', 'rb'))
        return response
    def big(self):
        response = FileResponse(open('webapp/big.json', 'rb'))
        return response
